#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"
#include "x86.h"
#include "traps.h"
#include "spinlock.h"

// Interrupt descriptor table (shared by all CPUs).
struct gatedesc idt[256];
extern uint vectors[];  // in vectors.S: array of 256 entry pointers
struct spinlock tickslock;
uint ticks;

struct trap_kernel_statis_s {
    int TRAP_ALL;
	int TRAP_DIVIDE;
	int TRAP_DEBUG;
	int TRAP_NMI;
	int TRAP_BRKPTRAP;
	int TRAP_OFLOW ;
	int TRAP_BOUND;
	int TRAP_ILLOP;
	int TRAP_DEVICE;
	int TRAP_DBLFLTRAP;
	int TRAP_COPROC;
	int TRAP_TRAPSS;
	int TRAP_SEGNP;
	int TRAP_STRAPACK;
	int TRAP_GPFLTRAP;
	int TRAP_PGFLTRAP;
	int TRAP_RES;
	int TRAP_FPERR;
	int TRAP_ALIGN;
	int TRAP_MCHK;
	int TRAP_SIMDERR;
	int TRAP_SYSCALL;
	int TRAP_DEFAULTRAP;
	int TRAP_IRQ_TRAPIMER;
	int TRAP_IRQ_KBD;
	int TRAP_IRQ_COM1;
	int TRAP_IRQ_IDE;
	int TRAP_IRQ_ERROR;
	int TRAP_IRQ_SPURIOUS;
};

struct trap_kernel_statis_s g_kernel_trap_statis;
void trap_statis_inc(uint trapno);


void
tvinit(void)
{
  int i;

  for(i = 0; i < 256; i++)
    SETGATE(idt[i], 0, SEG_KCODE<<3, vectors[i], 0);
  SETGATE(idt[T_SYSCALL], 1, SEG_KCODE<<3, vectors[T_SYSCALL], DPL_USER);

  initlock(&tickslock, "time");
}

void
idtinit(void)
{
  lidt(idt, sizeof(idt));
}

//PAGEBREAK: 41
void
trap(struct trapframe *tf)
{

  trap_statis_inc(tf->trapno);

  if(tf->trapno == T_SYSCALL){
    if(proc->killed)
      exit();
    proc->tf = tf;
    syscall();
    if(proc->killed)
      exit();
    return;
  }

  switch(tf->trapno){
  case T_IRQ0 + IRQ_TIMER:
    if(cpunum() == 0){
      acquire(&tickslock);
      ticks++;
      wakeup(&ticks);
      release(&tickslock);
    }
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE:
    ideintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_IDE+1:
    // Bochs generates spurious IDE1 interrupts.
    break;
  case T_IRQ0 + IRQ_KBD:
    kbdintr();
    lapiceoi();
    break;
  case T_IRQ0 + IRQ_COM1:
    uartintr();
    lapiceoi();
    break;
  case T_IRQ0 + 7:
  case T_IRQ0 + IRQ_SPURIOUS:
    cprintf("cpu%d: spurious interrupt at %x:%x\n",
            cpunum(), tf->cs, tf->eip);
    lapiceoi();
    break;

  //PAGEBREAK: 13
  default:
    if(proc == 0 || (tf->cs&3) == 0){
      // In kernel, it must be our mistake.
      cprintf("unexpected trap %d from cpu %d eip %x (cr2=0x%x)\n",
              tf->trapno, cpunum(), tf->eip, rcr2());
      panic("trap");
    }
    // In user space, assume process misbehaved.
    cprintf("pid %d %s: trap %d err %d on cpu %d "
            "eip 0x%x addr 0x%x--kill proc\n",
            proc->pid, proc->name, tf->trapno, tf->err, cpunum(), tf->eip,
            rcr2());
    proc->killed = 1;
  }

  // Force process exit if it has been killed and is in user space.
  // (If it is still executing in the kernel, let it keep running
  // until it gets to the regular system call return.)
  if(proc && proc->killed && (tf->cs&3) == DPL_USER)
    exit();

  // Force process to give up CPU on clock tick.
  // If interrupts were on while locks held, would need to check nlock.
  if(proc && proc->state == RUNNING && tf->trapno == T_IRQ0+IRQ_TIMER)
    yield();

  // Check if the process has been killed since we yielded
  if(proc && proc->killed && (tf->cs&3) == DPL_USER)
    exit();
}


void trap_statis_inc(uint trapno)
{
    g_kernel_trap_statis.TRAP_ALL++;

    switch (trapno) {
    case T_DIVIDE:
        g_kernel_trap_statis.TRAP_DIVIDE++;
        break;
    case T_DEBUG:
    	g_kernel_trap_statis.TRAP_DEBUG++;
    	break;
    case T_NMI:
    	g_kernel_trap_statis.TRAP_NMI++;
    	break;
    case T_BRKPT:
        g_kernel_trap_statis.TRAP_BRKPTRAP++;
    	break;
    case T_OFLOW:
        g_kernel_trap_statis.TRAP_OFLOW++;
    	break;
    case T_BOUND:
        g_kernel_trap_statis.TRAP_BOUND++;
    	break;
    case T_ILLOP:
        g_kernel_trap_statis.TRAP_ILLOP++;
    	break;
    case T_DEVICE:
        g_kernel_trap_statis.TRAP_DEVICE++;
    	break;
    case T_DBLFLT:
        g_kernel_trap_statis.TRAP_DBLFLTRAP++;
    	break;
    //case T_COPROC:
    //    g_kernel_trap_statis.TRAP_COPROC++;
    //	break;
    case T_TSS:
        g_kernel_trap_statis.TRAP_TRAPSS++;
    	break;
    case T_SEGNP:
        g_kernel_trap_statis.TRAP_SEGNP++;
    	break;
    case T_STACK:
        g_kernel_trap_statis.TRAP_STRAPACK++;
    	break;
    case T_GPFLT:
        g_kernel_trap_statis.TRAP_GPFLTRAP++;
    	break;
    case T_PGFLT:
        g_kernel_trap_statis.TRAP_PGFLTRAP++;
    	break;
    //case T_RES:
    //    g_kernel_trap_statis.TRAP_RES++;
    //	break;
    case T_FPERR:
        g_kernel_trap_statis.TRAP_FPERR++;
    	break;
    case T_ALIGN:
        g_kernel_trap_statis.TRAP_ALIGN++;
    	break;
    case T_MCHK:
        g_kernel_trap_statis.TRAP_MCHK++;
    	break;
    case T_SIMDERR:
        g_kernel_trap_statis.TRAP_SIMDERR++;
    	break;
    case T_SYSCALL:
        g_kernel_trap_statis.TRAP_SYSCALL++;
    	break;
    case T_DEFAULT:
        g_kernel_trap_statis.TRAP_DEFAULTRAP++;
    	break;
    case T_IRQ0 + IRQ_TIMER:
        g_kernel_trap_statis.TRAP_IRQ_TRAPIMER++;
    	break;
    case T_IRQ0 + IRQ_KBD:
        g_kernel_trap_statis.TRAP_IRQ_KBD++;
    	break;
    case T_IRQ0 + IRQ_COM1:
        g_kernel_trap_statis.TRAP_IRQ_COM1++;
    	break;
    case T_IRQ0 + IRQ_IDE:
        g_kernel_trap_statis.TRAP_IRQ_IDE++;
    	break;
    case T_IRQ0 + IRQ_ERROR:
        g_kernel_trap_statis.TRAP_IRQ_ERROR++;
    	break;
    case T_IRQ0 + IRQ_SPURIOUS:
        g_kernel_trap_statis.TRAP_IRQ_SPURIOUS++;
	    break;
    default:
        break;
    }

    return;
}

int trap_get_statis(void *data)
{
    memmove(data, &g_kernel_trap_statis, sizeof(g_kernel_trap_statis));

    return g_kernel_trap_statis.TRAP_ALL;
}

