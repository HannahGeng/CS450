--- sleep.c	2021-09-10 17:44:59.643419346 +0800
+++ sleep2.c	2021-10-11 07:44:56.303356843 +0800
@@ -9,6 +9,6 @@
 	}
 
 	int time = atoi(argv[1]);
-	sleep(time);
+	sleep(time2);
 	exit();
 }
