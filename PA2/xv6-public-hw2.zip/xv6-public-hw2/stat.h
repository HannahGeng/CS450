#define T_DIR  1   // Directory
#define T_FILE 2   // File
#define T_DEV  3   // Device

struct stat {
  short type;  // Type of file
  int dev;     // File system's disk device
  uint ino;    // Inode number
  short nlink; // Number of links to file
  uint size;   // Size of file in bytes
};

struct traps_count_s {
	int all_traps;

	int fork;
	int exit;
	int wait;
	int pipe;
	int write;
	int read;
	int close;
	int kill;
	int exec;
	int open;
	int mknod;
	int unlink;
	int fstat;
	int link;
	int mkdir;
	int chdir;
	int dup;
	int getpid;
	int sbrk;
	int sleep;
	int uptime;
    int countTraps;
};


struct trap_statis_s {
        int TRAP_ALL;
	int TRAP_DIVIDE;
	int TRAP_DEBUG;
	int TRAP_NMI;
	int TRAP_BRKPTRAP;
	int TRAP_OFLOW ;
	int TRAP_BOUND;
	int TRAP_ILLOP;
	int TRAP_DEVICE;
	int TRAP_DBLFLTRAP;
	int TRAP_COPROC;
	int TRAP_TRAPSS;
	int TRAP_SEGNP;
	int TRAP_STRAPACK;
	int TRAP_GPFLTRAP;
	int TRAP_PGFLTRAP;
	int TRAP_RES;
	int TRAP_FPERR;
	int TRAP_ALIGN;
	int TRAP_MCHK;
	int TRAP_SIMDERR;
	int TRAP_SYSCALL;
	int TRAP_DEFAULTRAP;
	int TRAP_IRQ_TRAPIMER;
	int TRAP_IRQ_KBD;
	int TRAP_IRQ_COM1;
	int TRAP_IRQ_IDE;
	int TRAP_IRQ_ERROR;
	int TRAP_IRQ_SPURIOUS;
};
